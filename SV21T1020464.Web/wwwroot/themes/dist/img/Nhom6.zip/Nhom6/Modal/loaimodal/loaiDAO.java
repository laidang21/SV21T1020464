package loaimodal;

import java.util.ArrayList;

public class loaiDAO {
	public ArrayList<loai> selectAll(){
		ArrayList<loai> ds = new ArrayList<loai>();
		ds.add(new loai("chinhtri","chinh tri"));
		ds.add(new loai("toan","toan"));
		ds.add(new loai("cntt","Cntt"));
		ds.add(new loai("dientu","ly"));
		return ds;
	}
}
