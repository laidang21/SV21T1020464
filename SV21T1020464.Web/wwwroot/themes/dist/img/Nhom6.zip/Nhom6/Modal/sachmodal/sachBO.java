package sachmodal;

import java.util.ArrayList;

public class sachBO {

    sachDAO sDAO = new sachDAO();
    ArrayList<sach> ds ;
	public ArrayList<sach> getsach(){
		ds = sDAO.selectAll();
		return ds;
	}
	public ArrayList<sach> timMa( String maloai){
		ArrayList<sach> tam = new ArrayList<sach>();
		for(sach s:ds) {
			if(s.getMaLoai().toLowerCase().trim().equals(maloai)) {
				tam.add(s);
		}}
		
		return tam;
	}
		public ArrayList<sach> tim( String key){
			ArrayList<sach> tam = new ArrayList<sach>();
			for(sach s:ds) {
				if(s.getMaLoai().toLowerCase().trim().contains(key)|| 
				   s.getTenSach().toLowerCase().trim().contains(key)|| 
				   s.getTacGia().toLowerCase().trim().contains(key) ) 
					tam.add(s);
				
			
			}
			return tam;
		}
}
