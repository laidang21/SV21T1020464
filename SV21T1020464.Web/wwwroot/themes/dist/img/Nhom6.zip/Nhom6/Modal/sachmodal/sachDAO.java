package sachmodal;

import java.util.ArrayList;

public class sachDAO {
	public ArrayList<sach> selectAll(){
		ArrayList<sach> ds = new ArrayList<sach>();
		ds.add(new sach("s1","Chinh tri","Thanh", (long)40,(long)10,"image_sach/b1.jpg","chinhtri"));
		ds.add(new sach("s2","Cong nghe thong tin","Loi", (long)40,(long)10,"image_sach/b11.jpg","cntt"));
		ds.add(new sach("s3","Tran Tien loi","Nam", (long)40,(long)10,"image_sach/b12.jpg","dientu"));
		ds.add(new sach("s4","Tran Tien loi","Loi", (long)40,(long)10,"image_sach/b14.jpg","toan"));
		ds.add(new sach("s5","Tran Tien loi","Loi1", (long)40,(long)10,"image_sach/b16.jpg","dientu"));
		ds.add(new sach("s6","Tran Tien loi","Loi3", (long)40,(long)10,"image_sach/b17.jpg","dientu"));
		ds.add(new sach("s7","Tran Tien loi","Loi2", (long)40,(long)10,"image_sach/b18.jpg","dientu"));
		return ds;
	}

}
