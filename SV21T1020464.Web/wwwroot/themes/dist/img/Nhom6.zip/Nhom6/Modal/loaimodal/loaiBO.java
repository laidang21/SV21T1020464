package loaimodal;

import java.util.ArrayList;

import sachmodal.sach;

public class loaiBO {
	loaiDAO lDAO = new loaiDAO();
	 ArrayList<loai> ds ;
	public ArrayList<loai> getloai(){
		return lDAO.selectAll();
	}
	public ArrayList<loai> timMa( String maloai){
		ArrayList<loai> tam = new ArrayList<loai>();
		for(loai l:ds) {
			if(l.getMaLoai().toLowerCase().trim().equals(maloai)) {
				tam.add(l);
		}
			}
		
		return tam;
	}

}
